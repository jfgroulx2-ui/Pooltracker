import { describe, expect, it } from "vitest";
import {
  careerCheck,
  computeNewEvents,
  computeStatus,
  detectCorrections,
  mergeGames,
  nextThreshold,
  numberGames,
  playoffTotal,
  regularSeasonTotal,
} from "../src/lib/milestones";
import { NOW, TODAY, entry, makePlayer, playoffGames, regularGames, thresholds } from "./helpers";

describe("numérotation des matchs", () => {
  it("attribue un numéro de carrière aux matchs de saison régulière seulement", () => {
    const games = numberGames([...playoffGames(3), ...regularGames(4)]);
    const regular = games.filter((g) => g.gameType === 2).map((g) => g.careerOrdinal);
    expect(regular).toEqual([1, 2, 3, 4]);
    expect(games.filter((g) => g.gameType === 3).every((g) => g.careerOrdinal === undefined)).toBe(true);
    expect(regularSeasonTotal(games)).toBe(4);
    expect(playoffTotal(games)).toBe(3);
  });

  it("trie par date puis par identifiant de match", () => {
    const a = regularGames(1, "2026-01-10", 2025020500)[0];
    const b = regularGames(1, "2026-01-10", 2025020499)[0];
    const c = regularGames(1, "2026-01-08", 2025020600)[0];
    const games = numberGames([a, b, c]);
    expect(games.map((g) => g.gameId)).toEqual([2025020600, 2025020499, 2025020500]);
  });

  it("fusionne sans doublon lors d'une synchronisation exécutée deux fois", () => {
    const first = regularGames(82);
    const merged = mergeGames(first, regularGames(82));
    expect(merged).toHaveLength(82);
    expect(numberGames(merged).at(-1)?.careerOrdinal).toBe(82);
  });
});

describe("seuils", () => {
  it("joueur à 82 matchs : 1 restant, aucun événement pour 83", () => {
    const player = makePlayer(regularGames(82));
    const events = computeNewEvents(player, thresholds, [], NOW);
    expect(events.map((e) => e.thresholdGames)).toEqual([20]);
    const status = computeStatus({ player, entry, thresholds, events: [], corrections: [], today: TODAY });
    expect(status.key).toBe("one");
    expect(status.remaining).toBe(1);
    expect(status.nextThreshold?.games).toBe(83);
  });

  it("joueur qui atteint 83 : la date est celle du 83e match, pas celle de la synchronisation", () => {
    const player = makePlayer(regularGames(83));
    const events = computeNewEvents(player, thresholds, [], NOW);
    const e83 = events.find((e) => e.thresholdGames === 83)!;
    const game83 = player.games.find((g) => g.careerOrdinal === 83)!;
    expect(e83.reachedOnGameDate).toBe(game83.date);
    expect(e83.gameId).toBe(game83.gameId);
    expect(e83.opponentAbbrev).toBe("TOR");
    expect(e83.validatedAt).toBe(NOW);
  });

  it("plusieurs seuils franchis entre deux synchronisations : un événement par seuil, dates distinctes", () => {
    const before = makePlayer(regularGames(82));
    const existing = computeNewEvents(before, thresholds, [], NOW); // seuil 20
    const after = makePlayer(regularGames(86));
    const fresh = computeNewEvents(after, thresholds, existing, NOW);
    expect(fresh.map((e) => e.thresholdGames).sort()).toEqual([83, 85]);
    expect(new Set(fresh.map((e) => e.reachedOnGameDate)).size).toBe(2);
  });

  it("est idempotent : un seuil déjà consigné n'est pas recréé", () => {
    const player = makePlayer(regularGames(90));
    const first = computeNewEvents(player, thresholds, [], NOW);
    const second = computeNewEvents(player, thresholds, first, NOW);
    expect(first).toHaveLength(3);
    expect(second).toHaveLength(0);
  });

  it("ignore les seuils inactifs et les matchs éliminatoires", () => {
    const player = makePlayer([...regularGames(199), ...playoffGames(10)]);
    const events = computeNewEvents(player, thresholds, [], NOW);
    expect(events.some((e) => e.thresholdGames === 200)).toBe(false);
    expect(regularSeasonTotal(player.games)).toBe(199);
  });

  it("prochain seuil : le plus petit seuil actif supérieur au total", () => {
    expect(nextThreshold(82, thresholds)?.games).toBe(83);
    expect(nextThreshold(84, thresholds)?.games).toBe(85);
    expect(nextThreshold(150, thresholds)).toBeNull(); // 200 est inactif
  });
});

describe("corrections rétroactives", () => {
  it("une baisse de 83 à 82 est signalée et liste l'événement remis en cause, sans le révoquer", () => {
    const events = computeNewEvents(makePlayer(regularGames(83)), thresholds, [], NOW);
    const corrections = detectCorrections(8480001, { regularSeason: 83, playoffs: 0 }, { regularSeason: 82, playoffs: 0 }, events, NOW);
    expect(corrections).toHaveLength(1);
    expect(corrections[0].affectedEventIds).toEqual(["8480001:thr-083"]);
    expect(events.every((e) => e.status === "reached")).toBe(true);
  });

  it("aucune correction en l'absence de données antérieures ou en cas de hausse", () => {
    expect(detectCorrections(1, null, { regularSeason: 5, playoffs: 0 }, [], NOW)).toHaveLength(0);
    expect(detectCorrections(1, { regularSeason: 4, playoffs: 0 }, { regularSeason: 5, playoffs: 0 }, [], NOW)).toHaveLength(0);
  });

  it("met le joueur en « Données à vérifier » tant qu'une correction n'est pas revue", () => {
    const player = makePlayer(regularGames(82));
    const status = computeStatus({
      player,
      entry,
      thresholds,
      events: [],
      corrections: [{ id: "x", nhlId: 8480001, detectedAt: NOW, field: "regularSeason", previous: 83, current: 82, affectedEventIds: [], reviewed: false }],
      today: TODAY,
    });
    expect(status.key).toBe("verify");
  });
});

describe("contrôle de cohérence et statuts", () => {
  it("détecte un écart entre le total de carrière rapporté et le journal", () => {
    const games = numberGames(regularGames(85));
    expect(careerCheck(85, games)).toBe(true);
    expect(careerCheck(86, games)).toBe(false);
    expect(careerCheck(null, games)).toBe(false);
    const player = makePlayer(regularGames(85), { totals: { regularSeason: 85, playoffs: 0, careerReported: 86, careerCheckOk: false } });
    expect(computeStatus({ player, entry, thresholds, events: [], corrections: [], today: TODAY }).key).toBe("verify");
  });

  it("gradue les statuts selon les matchs restants", () => {
    const at = (n: number) => computeStatus({ player: makePlayer(regularGames(n)), entry, thresholds, events: [], corrections: [], today: TODAY }).key;
    expect(at(82)).toBe("one");
    expect(at(78)).toBe("five");
    expect(at(68)).toBe("watch");
    expect(at(30)).toBe("far");
  });

  it("signale un seuil récemment atteint pendant 7 jours", () => {
    const player = makePlayer(regularGames(83));
    const recent = computeNewEvents(player, thresholds, [], NOW).map((e) => (e.thresholdGames === 83 ? { ...e, reachedOnGameDate: "2026-11-06" } : e));
    expect(computeStatus({ player, entry, thresholds, events: recent, corrections: [], today: TODAY }).key).toBe("recent");
    const old = recent.map((e) => ({ ...e, reachedOnGameDate: "2026-10-01" }));
    expect(computeStatus({ player, entry, thresholds, events: old, corrections: [], today: TODAY }).key).toBe("five"); // 83 → prochain 85, 2 restants
  });

  it("un joueur retiré du suivi ou inactif est gris", () => {
    const player = makePlayer(regularGames(50));
    expect(computeStatus({ player, entry: { ...entry, trackedUntil: NOW }, thresholds, events: [], corrections: [], today: TODAY }).key).toBe("inactive");
    expect(computeStatus({ player: { ...player, isActive: false }, entry, thresholds, events: [], corrections: [], today: TODAY }).key).toBe("inactive");
  });

  it("deux joueurs homonymes restent distincts par identifiant", () => {
    const a = makePlayer(regularGames(83), { nhlId: 1 });
    const b = makePlayer(regularGames(83), { nhlId: 2 });
    const events = [...computeNewEvents(a, thresholds, [], NOW), ...computeNewEvents(b, thresholds, [], NOW)];
    expect(new Set(events.map((e) => e.id)).size).toBe(events.length);
  });
});
