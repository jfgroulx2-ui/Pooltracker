/** Lecture et écriture validées des fichiers du dossier data/ (Node seulement). */
import { existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import type { z } from "zod";
import {
  CorrectionsSchema,
  EventsSchema,
  PlayerSchema,
  PoolSchema,
  SyncLogSchema,
  ThresholdsSchema,
  type Player,
} from "../src/lib/schemas";

export const DATA_DIR = process.env.POOL_DATA_DIR ?? join(process.cwd(), "data");
export const PLAYERS_DIR = join(DATA_DIR, "players");

export function readJson<S extends z.ZodTypeAny>(file: string, schema: S): z.output<S> {
  const raw = readFileSync(file, "utf8");
  const parsed = schema.safeParse(JSON.parse(raw));
  if (!parsed.success) {
    const issue = parsed.error.issues[0];
    throw new Error(`Fichier invalide ${file} : ${issue?.path.join(".")} — ${issue?.message}`);
  }
  return parsed.data;
}

export function stableStringify(value: unknown): string {
  return JSON.stringify(value, null, 2) + "\n";
}

/** Écrit le fichier seulement si son contenu change. Retourne true s'il a été écrit. */
export function writeJsonIfChanged<S extends z.ZodTypeAny>(file: string, schema: S, value: z.input<S>, dryRun = false): boolean {
  const parsed = schema.safeParse(value);
  if (!parsed.success) {
    const issue = parsed.error.issues[0];
    throw new Error(`Refus d'écrire ${file} : ${issue?.path.join(".")} — ${issue?.message}`);
  }
  const next = stableStringify(parsed.data);
  const prev = existsSync(file) ? readFileSync(file, "utf8") : null;
  if (prev === next) return false;
  if (!dryRun) {
    mkdirSync(dirname(file), { recursive: true });
    writeFileSync(file, next, "utf8");
  }
  return true;
}

export const paths = {
  pool: join(DATA_DIR, "pool.json"),
  thresholds: join(DATA_DIR, "thresholds.json"),
  events: join(DATA_DIR, "events.json"),
  corrections: join(DATA_DIR, "corrections.json"),
  syncLog: join(DATA_DIR, "sync-log.json"),
  player: (nhlId: number) => join(PLAYERS_DIR, `${nhlId}.json`),
};

export function loadAll() {
  return {
    pool: readJson(paths.pool, PoolSchema),
    thresholds: readJson(paths.thresholds, ThresholdsSchema),
    events: readJson(paths.events, EventsSchema),
    corrections: readJson(paths.corrections, CorrectionsSchema),
    syncLog: readJson(paths.syncLog, SyncLogSchema),
  };
}

export function loadPlayer(nhlId: number): Player | null {
  const file = paths.player(nhlId);
  return existsSync(file) ? readJson(file, PlayerSchema) : null;
}

export function listPlayerFiles(): number[] {
  if (!existsSync(PLAYERS_DIR)) return [];
  return readdirSync(PLAYERS_DIR)
    .filter((f) => f.endsWith(".json"))
    .map((f) => Number(f.replace(".json", "")))
    .filter((n) => Number.isFinite(n));
}
