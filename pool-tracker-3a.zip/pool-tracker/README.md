# Pool Tracker

Suivi des matchs NHL joués en carrière par les joueurs de votre pool de hockey et détection des seuils (83 matchs par défaut). Les données vivent dans ce dépôt GitHub, la synchronisation tourne dans GitHub Actions, le site est servi par Netlify.

**État : module 3a (socle).** Synchronisation, règles de calcul, authentification et tableau de bord minimal sont fonctionnels. Les écrans complets (ajout de joueurs depuis l'interface, recherche, fiche, seuils, journaux) suivent aux modules 3b à 3d.

## Arborescence

```
.github/workflows/sync.yml   synchronisation planifiée une fois par jour à 5 h (Montréal) + déclenchement manuel
data/                        source de vérité — JSON versionnés par Git
  pool.json                  joueurs suivis (propriétaire, note, retrait)
  thresholds.json            seuils (83 par défaut)
  players/{nhlId}.json       fiche, saisons NHL, journal de matchs numéroté, instantanés
  events.json                seuils atteints (date et id du match)
  corrections.json           baisses de total détectées, à vérifier
  sync-log.json              50 dernières exécutions
scripts/sync.ts              orchestration d'une synchronisation
scripts/store.ts             lecture/écriture validée des fichiers data/
src/lib/schemas.ts           contrat des fichiers (Zod)
src/lib/nhl-api.ts           client API NHL (cadence, reprises, validation)
src/lib/milestones.ts        numérotation, seuils, corrections, statuts
src/lib/time.ts              fuseau America/Toronto, saison courante
src/                         interface (Vite + React)
netlify/edge-functions/auth.ts   garde par mot de passe
tests/                       27 tests (unitaires + synchronisation hors ligne)
```

## Règles appliquées

- Un match joué = un match de **saison régulière NHL** (gameType 2) figurant au journal de matchs du joueur. Éliminatoires comptées à part, autres ligues ignorées.
- Le numéro de carrière est attribué en triant tous les matchs de saison régulière par date puis identifiant. La date d'atteinte d'un seuil *S* est celle du match n° *S*.
- Un match d'hier ou d'aujourd'hui n'est retenu que si la NHL le déclare officiel (`gameState = OFF`). Sinon il est repris à l'exécution suivante.
- Le total de carrière rapporté par la NHL doit égaler le nombre de lignes du journal ; un écart met le joueur en **Données à vérifier**.
- Une baisse de total n'est jamais appliquée en silence : elle est consignée dans `corrections.json` et les seuils concernés y sont listés sans être révoqués.
- Deux synchronisations identiques produisent le même résultat (aucun commit si rien ne change).

## Mise en route

### 1. Dépôt GitHub

1. Créez un dépôt **privé** (par exemple `pool-tracker`) et poussez-y le contenu de ce dossier.
2. Onglet **Actions** → activez les workflows si GitHub le demande.
3. **Settings → Actions → General → Workflow permissions** : cochez *Read and write permissions* (nécessaire pour que l'Action commette les données).

### 2. Mot de passe et secret de session

Dans un terminal (ou sur https://emn178.github.io/online-tools/sha256.html pour le hachage) :

```bash
node -e "console.log(require('crypto').createHash('sha256').update('VotreMotDePasse').digest('hex'))"
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

### 3. Netlify

1. **Add new site → Import an existing project** → choisissez le dépôt. Netlify lit `netlify.toml` : commande `npm run build`, dossier `dist`.
2. **Site configuration → Environment variables** : ajoutez `APP_PASSWORD_SHA256` et `SESSION_SECRET` (valeurs de l'étape 2).
3. Déployez. Le site demande le mot de passe, puis affiche un tableau de bord vide.

### 4. Premier joueur et première synchronisation

En attendant l'écran d'ajout (module 3b), éditez `data/pool.json` directement sur GitHub (icône crayon) :

```json
[
  { "nhlId": 8478402, "owner": "Moi", "note": null, "addedAt": "2026-11-08T00:00:00.000Z", "trackedUntil": null }
]
```

L'identifiant NHL figure dans l'adresse de la fiche du joueur sur nhl.com (`/player/prenom-nom-8478402`).

Puis **Actions → Synchronisation NHL → Run workflow**. En une à deux minutes : un commit `sync: …` apparaît, Netlify redéploie, le joueur est au tableau de bord avec son historique complet.

L'exécution planifiée (une fois par jour, 5 h à Montréal toute l'année) démarre ensuite seule. Un match non encore officiel à cette heure est repris le lendemain.

## Usage local (facultatif)

```bash
npm install
npm run dev          # interface sur http://localhost:5173 (sans mot de passe en local)
npm run sync:dry     # synchronisation sans écriture
npm run sync         # synchronisation réelle (modifie data/)
npm test             # 27 tests
npm run typecheck
```

## Sauvegarde et restauration

- **Sauvegarde** : le dépôt est la sauvegarde. `git clone` en conserve une copie complète avec tout l'historique.
- **Restauration d'un fichier** : GitHub → fichier → *History* → version voulue → copier. Ou `git revert <commit>` pour annuler une synchronisation entière.
- **Export** : les fichiers `data/*.json` se lisent dans Excel après conversion ; l'export CSV depuis l'interface arrive au module 3d.

## Limites connues

- L'API NHL n'est pas documentée officiellement et peut changer sans préavis. Les tests unitaires de l'Action servent de garde-fou ; un changement de format se verrait dans le journal des synchronisations.
- Les crons GitHub peuvent démarrer avec 10 à 30 minutes de retard ; la date d'atteinte d'un seuil provient du match, jamais de l'exécution, donc sans conséquence.
- GitHub désactive les crons d'un dépôt sans activité depuis 60 jours ; les commits de synchronisation maintiennent l'activité. Hors saison, un clic sur *Enable workflow* suffit.
- La connexion n'a pas de limitation de tentatives autre qu'un délai de 0,8 s par échec.
- Un joueur retraité ou envoyé dans une autre ligue reste `isActive = false` et passe en gris ; son historique est conservé.

## Prochaines étapes

- **3b — Données** : recherche de joueurs, ajout et retrait depuis l'interface (fonction Netlify → commit GitHub), notes, propriétaires.
- **3c — Seuils** : création, modification, désactivation, revue des corrections.
- **3d — Interface** : fiche joueur, historique des seuils, journal des synchronisations, export CSV, paramètres.
- **4 — Tests et contrôle qualité**, **5 — Procédure de déploiement détaillée**.
