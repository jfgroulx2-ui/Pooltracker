/**
 * Contrat des fichiers JSON du dossier data/.
 * Toute lecture et toute écriture passent par ces schémas : un fichier
 * malformé bloque la synchronisation plutôt que de corrompre les données.
 */
import { z } from "zod";

export const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

export const GameTypeSchema = z.union([z.literal(2), z.literal(3)]); // 2 = saison régulière, 3 = éliminatoires
export type GameType = z.infer<typeof GameTypeSchema>;

export const GameSchema = z.object({
  gameId: z.number().int(),
  date: z.string().regex(ISO_DATE),
  season: z.number().int(),
  gameType: GameTypeSchema,
  teamAbbrev: z.string(),
  opponentAbbrev: z.string(),
  homeAway: z.enum(["home", "away"]),
  /** Numéro cumulatif en carrière — uniquement pour la saison régulière. */
  careerOrdinal: z.number().int().positive().optional(),
});
export type Game = z.infer<typeof GameSchema>;

export const SeasonTotalSchema = z.object({
  season: z.number().int(),
  league: z.string(),
  gameType: GameTypeSchema,
  gamesPlayed: z.number().int().nonnegative(),
  teamName: z.string().nullable(),
});
export type SeasonTotal = z.infer<typeof SeasonTotalSchema>;

export const SnapshotSchema = z.object({
  fetchedAt: z.string(),
  regularSeason: z.number().int().nonnegative(),
  playoffs: z.number().int().nonnegative(),
  source: z.string(),
});
export type Snapshot = z.infer<typeof SnapshotSchema>;

export const PlayerSchema = z.object({
  nhlId: z.number().int(),
  firstName: z.string(),
  lastName: z.string(),
  fullName: z.string(),
  position: z.string(),
  teamAbbrev: z.string().nullable(),
  isActive: z.boolean(),
  headshotUrl: z.string().nullable(),
  seasons: z.array(SeasonTotalSchema),
  games: z.array(GameSchema),
  totals: z.object({
    regularSeason: z.number().int().nonnegative(),
    playoffs: z.number().int().nonnegative(),
    /** Total de carrière tel que rapporté par la fiche NHL (contrôle de cohérence). */
    careerReported: z.number().int().nonnegative().nullable(),
    careerCheckOk: z.boolean(),
  }),
  snapshots: z.array(SnapshotSchema),
  lastSyncedAt: z.string(),
  lastGameDate: z.string().regex(ISO_DATE).nullable(),
});
export type Player = z.infer<typeof PlayerSchema>;

export const PoolEntrySchema = z.object({
  nhlId: z.number().int(),
  owner: z.string().nullable(),
  note: z.string().nullable(),
  addedAt: z.string(),
  /** Date de retrait du suivi ; null = suivi actif. L'historique est conservé. */
  trackedUntil: z.string().nullable(),
});
export type PoolEntry = z.infer<typeof PoolEntrySchema>;
export const PoolSchema = z.array(PoolEntrySchema);

export const ThresholdSchema = z.object({
  id: z.string().min(1),
  label: z.string().min(1),
  description: z.string().nullable(),
  games: z.number().int().positive(),
  countsPlayoffs: z.literal(false), // réservé à une évolution future
  isActive: z.boolean(),
  createdAt: z.string(),
  deactivatedAt: z.string().nullable(),
});
export type Threshold = z.infer<typeof ThresholdSchema>;
export const ThresholdsSchema = z.array(ThresholdSchema);

export const ThresholdEventSchema = z.object({
  id: z.string().min(1),
  nhlId: z.number().int(),
  thresholdId: z.string(),
  thresholdGames: z.number().int().positive(),
  /** Date du match officiel au cours duquel le seuil a été atteint. */
  reachedOnGameDate: z.string().regex(ISO_DATE),
  gameId: z.number().int(),
  opponentAbbrev: z.string(),
  totalAtEvent: z.number().int().positive(),
  validatedAt: z.string(),
  status: z.enum(["reached", "revoked"]),
  revokedAt: z.string().nullable(),
});
export type ThresholdEvent = z.infer<typeof ThresholdEventSchema>;
export const EventsSchema = z.array(ThresholdEventSchema);

export const CorrectionSchema = z.object({
  id: z.string().min(1),
  nhlId: z.number().int(),
  detectedAt: z.string(),
  field: z.enum(["regularSeason", "playoffs"]),
  previous: z.number().int().nonnegative(),
  current: z.number().int().nonnegative(),
  affectedEventIds: z.array(z.string()),
  reviewed: z.boolean(),
});
export type Correction = z.infer<typeof CorrectionSchema>;
export const CorrectionsSchema = z.array(CorrectionSchema);

export const SyncRunSchema = z.object({
  runId: z.string(),
  startedAt: z.string(),
  finishedAt: z.string().nullable(),
  trigger: z.enum(["scheduled", "manual", "backfill"]),
  mode: z.enum(["incremental", "full", "player"]),
  dryRun: z.boolean(),
  playersChecked: z.number().int().nonnegative(),
  playersUpdated: z.number().int().nonnegative(),
  eventsCreated: z.number().int().nonnegative(),
  correctionsCreated: z.number().int().nonnegative(),
  skippedPending: z.number().int().nonnegative(),
  errors: z.array(z.object({ nhlId: z.number().int().nullable(), message: z.string() })),
  status: z.enum(["success", "partial", "failed"]),
});
export type SyncRun = z.infer<typeof SyncRunSchema>;
export const SyncLogSchema = z.array(SyncRunSchema);
