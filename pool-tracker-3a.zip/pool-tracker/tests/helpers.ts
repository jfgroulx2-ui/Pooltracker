import type { Game, Player, PoolEntry, Threshold } from "../src/lib/schemas";
import { numberGames } from "../src/lib/milestones";

export const NOW = "2026-11-08T11:02:00.000Z";
export const TODAY = "2026-11-08";

export function regularGames(count: number, startDate = "2024-10-09", startId = 2024020001): Game[] {
  const out: Game[] = [];
  for (let i = 0; i < count; i++) {
    const d = new Date(`${startDate}T12:00:00Z`);
    d.setUTCDate(d.getUTCDate() + i * 3);
    out.push({ gameId: startId + i, date: d.toISOString().slice(0, 10), season: 20242025, gameType: 2, teamAbbrev: "MTL", opponentAbbrev: "TOR", homeAway: "home" });
  }
  return out;
}

export function playoffGames(count: number, startId = 2024030111): Game[] {
  return Array.from({ length: count }, (_, i) => ({
    gameId: startId + i,
    date: `2025-04-${String(20 + i).padStart(2, "0")}`,
    season: 20242025,
    gameType: 3 as const,
    teamAbbrev: "MTL",
    opponentAbbrev: "WSH",
    homeAway: "away" as const,
  }));
}

export function makePlayer(games: Game[], overrides: Partial<Player> = {}): Player {
  const numbered = numberGames(games);
  const regular = numbered.filter((g) => g.gameType === 2).length;
  return {
    nhlId: 8480001,
    firstName: "Émile",
    lastName: "Lavoie",
    fullName: "Émile Lavoie",
    position: "C",
    teamAbbrev: "MTL",
    isActive: true,
    headshotUrl: null,
    seasons: [],
    games: numbered,
    totals: { regularSeason: regular, playoffs: numbered.length - regular, careerReported: regular, careerCheckOk: true },
    snapshots: [],
    lastSyncedAt: NOW,
    lastGameDate: numbered.at(-1)?.date ?? null,
    ...overrides,
  };
}

export const entry: PoolEntry = { nhlId: 8480001, owner: "Moi", note: null, addedAt: NOW, trackedUntil: null };

export const thresholds: Threshold[] = [
  { id: "thr-020", label: "20", description: null, games: 20, countsPlayoffs: false, isActive: true, createdAt: NOW, deactivatedAt: null },
  { id: "thr-083", label: "83", description: null, games: 83, countsPlayoffs: false, isActive: true, createdAt: NOW, deactivatedAt: null },
  { id: "thr-085", label: "85", description: null, games: 85, countsPlayoffs: false, isActive: true, createdAt: NOW, deactivatedAt: null },
  { id: "thr-200", label: "200", description: null, games: 200, countsPlayoffs: false, isActive: false, createdAt: NOW, deactivatedAt: NOW },
];
