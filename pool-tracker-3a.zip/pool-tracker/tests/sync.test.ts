/**
 * Test d'intégration hors ligne : la synchronisation complète tourne contre
 * une API NHL simulée (réponses enregistrées) dans un dossier data/ temporaire.
 */
import { mkdtempSync, readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { beforeAll, describe, expect, it } from "vitest";
import landing from "./fixtures/landing.json";
import gameLog from "./fixtures/game-log.json";
import score from "./fixtures/score.json";

const dir = mkdtempSync(join(tmpdir(), "pool-tracker-"));
process.env.POOL_DATA_DIR = dir;

// Importés après la variable d'environnement : store.ts lit POOL_DATA_DIR au chargement.
const { runSync } = await import("../scripts/sync");
const { NhlClient } = await import("../src/lib/nhl-api");
const { PlayerSchema, EventsSchema, SyncLogSchema } = await import("../src/lib/schemas");

const NOW = new Date("2026-11-08T11:02:00Z");
const requests: string[] = [];

/** 81 matchs de saison régulière répartis sur 2024-2025 (9) et 2025-2026 (58), puis la saison courante (fixture : 2 matchs ... complétée à 15). */
function fakeGameLog(season: number, type: number) {
  if (type === 3) {
    return { seasonId: season, gameTypeId: 3, gameLog: Array.from({ length: 5 }, (_, i) => ({ gameId: 2025030100 + i, teamAbbrev: "MTL", homeRoadFlag: "H", gameDate: `2026-04-${20 + i}`, opponentAbbrev: "WSH" })) };
  }
  const counts: Record<number, number> = { 20242025: 9, 20252026: 58, 20262027: 15 };
  const n = counts[season] ?? 0;
  const year = Math.floor(season / 10000);
  const games = Array.from({ length: n }, (_, i) => {
    const d = new Date(Date.UTC(year, 9, 8 + i * 2)); // à partir du 8 octobre, tous les 2 jours
    return { gameId: season * 100 + i, teamAbbrev: "MTL", homeRoadFlag: i % 2 ? "H" : "R", gameDate: d.toISOString().slice(0, 10), opponentAbbrev: i % 3 ? "TOR" : "BOS" };
  });
  // Les deux derniers matchs de la saison courante reprennent la fixture (7 nov. officiel, 5 nov.)
  if (season === 20262027) {
    games.splice(-2, 2, ...gameLog.gameLog.map((g) => ({ ...g })));
  }
  return { seasonId: season, gameTypeId: 2, gameLog: games };
}

const fetchImpl = (async (input: string | URL | Request) => {
  const url = String(input);
  requests.push(url);
  const json = (body: unknown) => new Response(JSON.stringify(body), { status: 200, headers: { "content-type": "application/json" } });
  if (url.endsWith("/player/8480001/landing")) return json(landing);
  const gl = url.match(/game-log\/(\d+)\/(\d)$/);
  if (gl) return json(fakeGameLog(Number(gl[1]), Number(gl[2])));
  if (url.includes("/score/")) return json(score);
  return new Response("", { status: 404 });
}) as unknown as typeof fetch;

describe("synchronisation de bout en bout (API simulée)", () => {
  beforeAll(() => {
    mkdirSync(join(dir, "players"), { recursive: true });
    writeFileSync(join(dir, "pool.json"), JSON.stringify([{ nhlId: 8480001, owner: "Moi", note: null, addedAt: NOW.toISOString(), trackedUntil: null }]));
    writeFileSync(join(dir, "thresholds.json"), readFileSync(join(process.cwd(), "data/thresholds.json"), "utf8"));
    for (const f of ["events.json", "corrections.json", "sync-log.json"]) writeFileSync(join(dir, f), "[]");
  });

  it("reconstruit un nouveau joueur, numérote sa carrière et consigne la synchronisation", async () => {
    const client = new NhlClient({ fetchImpl, minIntervalMs: 0, retries: 1 });
    const run = await runSync({ all: false, dryRun: false, player: null, trigger: "scheduled" }, { client, now: NOW });

    expect(run.status).toBe("success");
    expect(run.playersChecked).toBe(1);
    expect(run.playersUpdated).toBe(1);
    expect(run.skippedPending).toBe(0);

    const player = PlayerSchema.parse(JSON.parse(readFileSync(join(dir, "players", "8480001.json"), "utf8")));
    expect(player.fullName).toBe("Émile Lavoie");
    expect(player.totals.regularSeason).toBe(82);
    expect(player.totals.playoffs).toBe(5);
    expect(player.totals.careerCheckOk).toBe(true);
    expect(player.games.filter((g) => g.gameType === 2).at(-1)?.careerOrdinal).toBe(82);
    expect(player.lastGameDate).toBe("2026-11-07");
    expect(player.snapshots).toHaveLength(1);

    // Seul le seuil 83 est configuré : à 82 matchs, aucun événement.
    const events = EventsSchema.parse(JSON.parse(readFileSync(join(dir, "events.json"), "utf8")));
    expect(events).toHaveLength(0);

    const log = SyncLogSchema.parse(JSON.parse(readFileSync(join(dir, "sync-log.json"), "utf8")));
    expect(log[0].trigger).toBe("scheduled");
    expect(requests.some((u) => u.includes("/game-log/20242025/2"))).toBe(true); // reconstruction complète
    expect(requests.some((u) => u.includes("/game-log/20252026/3"))).toBe(true); // éliminatoires suivies à part
    expect(requests.some((u) => u.includes("/score/2026-11-07"))).toBe(true); // validation OFF du match d'hier
    expect(existsSync(join(process.cwd(), ".sync-commit-message"))).toBe(true);
  });

  it("une deuxième exécution ne change rien", async () => {
    const before = readFileSync(join(dir, "players", "8480001.json"), "utf8");
    const client = new NhlClient({ fetchImpl, minIntervalMs: 0, retries: 1 });
    const run = await runSync({ all: false, dryRun: false, player: null, trigger: "scheduled" }, { client, now: NOW });
    expect(run.playersUpdated).toBe(0);
    const after = readFileSync(join(dir, "players", "8480001.json"), "utf8");
    // Seul lastSyncedAt bouge ; totaux, matchs et instantanés identiques.
    expect(JSON.parse(after).games).toEqual(JSON.parse(before).games);
    expect(JSON.parse(after).snapshots).toEqual(JSON.parse(before).snapshots);
  });
});
