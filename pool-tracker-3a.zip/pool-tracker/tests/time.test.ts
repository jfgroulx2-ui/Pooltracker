import { describe, expect, it } from "vitest";
import { currentSeasonId, daysBetween, isMonday, localDate, shiftDate, yesterdayLocal } from "../src/lib/time";

describe("fuseau et saison", () => {
  it("convertit un instant UTC en date civile de Montréal", () => {
    expect(localDate(new Date("2026-11-08T03:30:00Z"))).toBe("2026-11-07"); // 22 h 30 la veille à Montréal
    expect(localDate(new Date("2026-11-08T11:02:00Z"))).toBe("2026-11-08");
    expect(yesterdayLocal(new Date("2026-11-08T11:02:00Z"))).toBe("2026-11-07");
  });
  it("calcule la saison courante avec bascule en septembre", () => {
    expect(currentSeasonId("2026-11-08")).toBe(20262027);
    expect(currentSeasonId("2027-04-15")).toBe(20262027);
    expect(currentSeasonId("2027-08-30")).toBe(20262027);
    expect(currentSeasonId("2027-09-15")).toBe(20272028);
  });
  it("utilitaires de dates", () => {
    expect(shiftDate("2026-03-01", -1)).toBe("2026-02-28");
    expect(daysBetween("2026-11-01", "2026-11-08")).toBe(7);
    expect(isMonday("2026-11-09")).toBe(true);
    expect(isMonday("2026-11-08")).toBe(false);
  });
});
