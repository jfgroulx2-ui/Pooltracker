/**
 * Synchronisation avec la NHL.
 *
 *   npx tsx scripts/sync.ts                          # incrémentale (équipes ayant joué hier)
 *   npx tsx scripts/sync.ts --all                    # tous les joueurs suivis
 *   npx tsx scripts/sync.ts --player 8478402         # (re)construction complète d'un joueur
 *   npx tsx scripts/sync.ts --dry-run                # calcule sans écrire
 *   --trigger scheduled|manual|backfill              # pour le journal
 *
 * Écrit .sync-commit-message (message normalisé pour le commit de l'Action).
 */
import { writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";
import { mapGameLog, mapLanding, NhlClient, officialGameIds, teamsThatPlayed, type ScoreRaw } from "../src/lib/nhl-api";
import {
  careerCheck,
  computeNewEvents,
  detectCorrections,
  lastGameDate,
  mergeGames,
  numberGames,
  playoffTotal,
  regularSeasonTotal,
} from "../src/lib/milestones";
import {
  CorrectionsSchema,
  EventsSchema,
  PlayerSchema,
  SyncLogSchema,
  type Correction,
  type Game,
  type Player,
  type SyncRun,
  type Threshold,
  type ThresholdEvent,
} from "../src/lib/schemas";
import { currentSeasonId, isMonday, localDate, yesterdayLocal } from "../src/lib/time";
import { loadAll, loadPlayer, paths, writeJsonIfChanged } from "./store";

export interface Args {
  all: boolean;
  dryRun: boolean;
  player: number | null;
  trigger: SyncRun["trigger"];
}

function parseArgs(argv: string[]): Args {
  const args: Args = { all: false, dryRun: false, player: null, trigger: "manual" };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--all") args.all = true;
    else if (a === "--dry-run") args.dryRun = true;
    else if (a === "--player") args.player = Number(argv[++i]);
    else if (a === "--trigger") args.trigger = argv[++i] as SyncRun["trigger"];
  }
  if (args.player !== null && !Number.isFinite(args.player)) throw new Error("--player attend un identifiant NHL numérique");
  return args;
}

const log = (msg: string) => console.log(`[sync] ${msg}`);

/** Cache des scores par date pour la validation des matchs récents. */
class ScoreCache {
  private cache = new Map<string, ScoreRaw>();
  constructor(private client: NhlClient) {}
  async get(date: string): Promise<ScoreRaw> {
    const hit = this.cache.get(date);
    if (hit) return hit;
    const s = await this.client.getScores(date);
    this.cache.set(date, s);
    return s;
  }
}

interface PlayerResult {
  player: Player;
  changed: boolean;
  newEvents: ThresholdEvent[];
  newCorrections: Correction[];
  skippedPending: number;
}

/**
 * Récupère et recalcule un joueur.
 *  - full = toutes les saisons NHL (ajout d'un joueur, rafraîchissement forcé)
 *  - sinon seulement la saison courante
 */
async function syncPlayer(
  client: NhlClient,
  scores: ScoreCache,
  nhlId: number,
  existing: Player | null,
  thresholds: Threshold[],
  events: ThresholdEvent[],
  opts: { full: boolean; today: string; now: string },
): Promise<PlayerResult> {
  const identity = mapLanding(await client.getPlayerLanding(nhlId));
  const season = currentSeasonId(opts.today);

  const seasonsToFetch = opts.full
    ? identity.seasons.filter((s) => s.gamesPlayed > 0)
    : identity.seasons.filter((s) => s.season === season && s.gamesPlayed > 0);
  // Un joueur en début de saison peut ne pas encore figurer dans seasonTotals : on interroge quand même la saison courante.
  if (!opts.full && !seasonsToFetch.some((s) => s.season === season && s.gameType === 2)) {
    seasonsToFetch.push({ season, league: "NHL", gameType: 2, gamesPlayed: 0, teamName: null });
  }

  let incoming: Game[] = [];
  for (const s of seasonsToFetch) {
    const raw = await client.getGameLog(nhlId, s.season, s.gameType);
    incoming = incoming.concat(mapGameLog(raw, s.season, s.gameType));
  }

  // Un match d'hier ou d'aujourd'hui n'est retenu que si la NHL le déclare officiel (OFF).
  let skippedPending = 0;
  const recentDates = new Set(incoming.map((g) => g.date).filter((d) => d >= yesterdayLocal(new Date(`${opts.today}T12:00:00Z`))));
  const official = new Map<string, Set<number>>();
  for (const d of recentDates) official.set(d, officialGameIds(await scores.get(d)));
  incoming = incoming.filter((g) => {
    const ids = official.get(g.date);
    if (!ids) return true;
    if (ids.has(g.gameId)) return true;
    skippedPending++;
    return false;
  });

  const games = numberGames(mergeGames(existing?.games ?? [], incoming));
  const totals = {
    regularSeason: regularSeasonTotal(games),
    playoffs: playoffTotal(games),
    careerReported: identity.careerReportedRegular,
    careerCheckOk: careerCheck(identity.careerReportedRegular, games),
  };

  const previousTotals = existing ? { regularSeason: existing.totals.regularSeason, playoffs: existing.totals.playoffs } : null;
  const totalsChanged = !previousTotals || previousTotals.regularSeason !== totals.regularSeason || previousTotals.playoffs !== totals.playoffs;
  const snapshots = [...(existing?.snapshots ?? [])];
  if (totalsChanged) snapshots.push({ fetchedAt: opts.now, regularSeason: totals.regularSeason, playoffs: totals.playoffs, source: "api-web.nhle.com" });

  const player: Player = {
    nhlId,
    firstName: identity.firstName,
    lastName: identity.lastName,
    fullName: identity.fullName,
    position: identity.position,
    teamAbbrev: identity.teamAbbrev,
    isActive: identity.isActive,
    headshotUrl: identity.headshotUrl,
    seasons: identity.seasons,
    games,
    totals,
    snapshots,
    lastSyncedAt: opts.now,
    lastGameDate: lastGameDate(games),
  };

  const newEvents = computeNewEvents(player, thresholds, events, opts.now);
  const newCorrections = detectCorrections(nhlId, previousTotals, totals, events, opts.now);

  const changed =
    !existing ||
    totalsChanged ||
    existing.teamAbbrev !== player.teamAbbrev ||
    existing.isActive !== player.isActive ||
    existing.games.length !== player.games.length ||
    newEvents.length > 0;

  return { player, changed, newEvents, newCorrections, skippedPending };
}

export async function runSync(args: Args, options: { client?: NhlClient; now?: Date } = {}): Promise<SyncRun> {
  const now = options.now ?? new Date();
  const nowIso = now.toISOString();
  const today = localDate(now);
  const yesterday = yesterdayLocal(now);
  const data = loadAll();
  const client = options.client ?? new NhlClient({ log });
  const scores = new ScoreCache(client);

  const run: SyncRun = {
    runId: nowIso.replace(/[-:.TZ]/g, "").slice(0, 14),
    startedAt: nowIso,
    finishedAt: null,
    trigger: args.trigger,
    mode: args.player !== null ? "player" : args.all ? "full" : "incremental",
    dryRun: args.dryRun,
    playersChecked: 0,
    playersUpdated: 0,
    eventsCreated: 0,
    correctionsCreated: 0,
    skippedPending: 0,
    errors: [],
    status: "success",
  };

  // 1. Qui traiter ?
  const tracked = data.pool.filter((p) => p.trackedUntil === null);
  let targets: { nhlId: number; full: boolean }[];
  if (args.player !== null) {
    targets = [{ nhlId: args.player, full: true }];
  } else {
    const fullRefresh = args.all || isMonday(today);
    let played: Set<string> | null = null;
    if (!fullRefresh) {
      try {
        played = teamsThatPlayed(await scores.get(yesterday));
        log(`${played.size} équipes ont joué le ${yesterday}`);
      } catch (err) {
        log(`Scores du ${yesterday} indisponibles (${(err as Error).message}) : rafraîchissement complet.`);
      }
    }
    targets = tracked
      .map((p) => ({ entry: p, player: loadPlayer(p.nhlId) }))
      .filter(({ player }) => played === null || player === null || (player.teamAbbrev !== null && played.has(player.teamAbbrev)))
      .map(({ entry, player }) => ({ nhlId: entry.nhlId, full: player === null }));
    log(`${targets.length} joueur(s) à traiter sur ${tracked.length} suivi(s) — mode ${run.mode}${fullRefresh ? " (rafraîchissement complet)" : ""}`);
  }

  // 2. Traitement
  let events = [...data.events];
  let corrections = [...data.corrections];
  const updatedNames: string[] = [];
  for (const t of targets) {
    run.playersChecked++;
    try {
      const existing = loadPlayer(t.nhlId);
      const result = await syncPlayer(client, scores, t.nhlId, existing, data.thresholds, events, { full: t.full, today, now: nowIso });
      run.skippedPending += result.skippedPending;
      if (result.newEvents.length) {
        events = events.concat(result.newEvents);
        run.eventsCreated += result.newEvents.length;
        for (const e of result.newEvents) log(`SEUIL ${e.thresholdGames} atteint : ${result.player.fullName} le ${e.reachedOnGameDate} vs ${e.opponentAbbrev}`);
      }
      if (result.newCorrections.length) {
        corrections = corrections.concat(result.newCorrections);
        run.correctionsCreated += result.newCorrections.length;
        for (const c of result.newCorrections) log(`CORRECTION potentielle : ${result.player.fullName} ${c.field} ${c.previous} → ${c.current}`);
      }
      const wrote = writeJsonIfChanged(paths.player(t.nhlId), PlayerSchema, result.player, args.dryRun);
      if (wrote && result.changed) {
        run.playersUpdated++;
        updatedNames.push(result.player.lastName);
      }
      log(`${result.player.fullName} — rég. ${result.player.totals.regularSeason}, élim. ${result.player.totals.playoffs}${result.player.totals.careerCheckOk ? "" : " — ÉCART carrière/journal"}`);
    } catch (err) {
      const message = (err as Error).message;
      run.errors.push({ nhlId: t.nhlId, message });
      log(`ERREUR joueur ${t.nhlId} : ${message}`);
      if (run.errors.length > Math.max(3, Math.ceil(targets.length * 0.05))) {
        log("Trop d'erreurs : arrêt propre, les données déjà écrites sont conservées.");
        break;
      }
    }
  }

  // 3. Écritures globales
  writeJsonIfChanged(paths.events, EventsSchema, events, args.dryRun);
  writeJsonIfChanged(paths.corrections, CorrectionsSchema, corrections, args.dryRun);

  run.finishedAt = new Date().toISOString();
  run.status = run.errors.length === 0 ? "success" : run.playersChecked > run.errors.length ? "partial" : "failed";
  const syncLog = [run, ...data.syncLog].slice(0, 50);
  writeJsonIfChanged(paths.syncLog, SyncLogSchema, syncLog, args.dryRun);

  // 4. Message de commit normalisé
  const parts = [`sync: ${today} — ${run.playersUpdated} joueur(s) mis à jour`];
  if (run.eventsCreated) parts.push(`${run.eventsCreated} seuil(s) atteint(s)`);
  if (run.correctionsCreated) parts.push(`${run.correctionsCreated} correction(s) à vérifier`);
  if (run.errors.length) parts.push(`${run.errors.length} erreur(s)`);
  const message = parts.join(", ") + (updatedNames.length ? `\n\n${updatedNames.join(", ")}` : "");
  if (!args.dryRun) writeFileSync(".sync-commit-message", message + "\n", "utf8");

  log(`Terminé : ${run.status} — ${client.requestCount} requêtes — ${message.split("\n")[0]}`);
  return run;
}

const invokedDirectly = process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href;
if (invokedDirectly) {
  runSync(parseArgs(process.argv.slice(2)))
    .then((run) => {
      if (run.status === "failed") process.exitCode = 1;
    })
    .catch((err) => {
      console.error(`[sync] Échec : ${(err as Error).message}`);
      process.exitCode = 1;
    });
}
