/**
 * Garde par mot de passe devant tout le site (un seul utilisateur).
 * Variables Netlify requises : APP_PASSWORD_SHA256, SESSION_SECRET.
 *
 * - GET  /login   → formulaire
 * - POST /login   → vérifie le mot de passe, pose un témoin signé (30 jours)
 * - GET  /logout  → supprime le témoin
 * - toute autre route → exige un témoin valide
 */
const COOKIE = "pt_session";
const MAX_AGE = 60 * 60 * 24 * 30;

declare const Netlify: { env: { get(name: string): string | undefined } };

async function sha256Hex(text: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function hmacHex(secret: string, text: string): Promise<string> {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(text));
  return [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function readCookie(req: Request): string | null {
  const header = req.headers.get("cookie") ?? "";
  const m = header.match(new RegExp(`(?:^|;\\s*)${COOKIE}=([^;]+)`));
  return m ? decodeURIComponent(m[1]) : null;
}

async function isValidSession(token: string | null, secret: string): Promise<boolean> {
  if (!token) return false;
  const [issued, sig] = token.split(".");
  if (!issued || !sig) return false;
  const age = Math.floor(Date.now() / 1000) - Number(issued);
  if (!Number.isFinite(age) || age < 0 || age > MAX_AGE) return false;
  return timingSafeEqual(await hmacHex(secret, issued), sig);
}

function loginPage(error = ""): Response {
  const html = `<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Pool Tracker — Connexion</title>
<style>
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0F2A5A;font-family:Inter,system-ui,sans-serif;color:#111827}
form{background:#fff;padding:32px;width:min(360px,90vw);display:flex;flex-direction:column;gap:14px}
h1{margin:0 0 4px;font-size:24px}label{font-size:13px;font-weight:600;color:#4B5563}
input{min-height:44px;padding:0 12px;border:1px solid #CBD2DA;font-size:16px}
button{min-height:44px;background:#1D4ED8;color:#fff;border:0;font-weight:600;font-size:15px;cursor:pointer}
.err{color:#991B1B;font-size:14px;margin:0}
</style></head><body>
<form method="post" action="/login"><h1>Pool Tracker</h1>
<label for="p">Mot de passe</label><input id="p" name="password" type="password" autocomplete="current-password" required autofocus>
${error ? `<p class="err">${error}</p>` : ""}
<button type="submit">Se connecter</button></form></body></html>`;
  return new Response(html, { status: error ? 401 : 200, headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" } });
}

export default async (request: Request, context: { next: () => Promise<Response> }) => {
  const url = new URL(request.url);
  const expectedHash = Netlify.env.get("APP_PASSWORD_SHA256");
  const secret = Netlify.env.get("SESSION_SECRET");

  if (!expectedHash || !secret) {
    return new Response("Configuration incomplète : définir APP_PASSWORD_SHA256 et SESSION_SECRET dans Netlify.", { status: 500 });
  }

  if (url.pathname === "/logout") {
    return new Response(null, { status: 302, headers: { location: "/login", "set-cookie": `${COOKIE}=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax` } });
  }

  if (url.pathname === "/login") {
    if (request.method !== "POST") return loginPage();
    const form = await request.formData();
    const password = String(form.get("password") ?? "");
    const ok = timingSafeEqual(await sha256Hex(password), expectedHash.toLowerCase());
    if (!ok) {
      await new Promise((r) => setTimeout(r, 800)); // ralentit la force brute
      return loginPage("Mot de passe incorrect.");
    }
    const issued = String(Math.floor(Date.now() / 1000));
    const token = `${issued}.${await hmacHex(secret, issued)}`;
    return new Response(null, {
      status: 302,
      headers: { location: "/", "set-cookie": `${COOKIE}=${encodeURIComponent(token)}; Path=/; Max-Age=${MAX_AGE}; HttpOnly; Secure; SameSite=Lax` },
    });
  }

  if (await isValidSession(readCookie(request), secret)) return context.next();
  return new Response(null, { status: 302, headers: { location: "/login" } });
};

export const config = { path: "/*" };
