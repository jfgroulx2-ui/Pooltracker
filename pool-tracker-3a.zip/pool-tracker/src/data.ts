/** Chargement des fichiers data/ au moment de la construction du site. */
import {
  CorrectionsSchema,
  EventsSchema,
  PlayerSchema,
  PoolSchema,
  SyncLogSchema,
  ThresholdsSchema,
  type Player,
} from "./lib/schemas";
import poolRaw from "../data/pool.json";
import thresholdsRaw from "../data/thresholds.json";
import eventsRaw from "../data/events.json";
import correctionsRaw from "../data/corrections.json";
import syncLogRaw from "../data/sync-log.json";

const playerModules = import.meta.glob("../data/players/*.json", { eager: true, import: "default" }) as Record<string, unknown>;

export const pool = PoolSchema.parse(poolRaw);
export const thresholds = ThresholdsSchema.parse(thresholdsRaw);
export const events = EventsSchema.parse(eventsRaw);
export const corrections = CorrectionsSchema.parse(correctionsRaw);
export const syncLog = SyncLogSchema.parse(syncLogRaw);
export const players: Map<number, Player> = new Map(
  Object.values(playerModules).map((raw) => {
    const p = PlayerSchema.parse(raw);
    return [p.nhlId, p];
  }),
);
