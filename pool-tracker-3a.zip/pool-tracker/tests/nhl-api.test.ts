import { describe, expect, it } from "vitest";
import landing from "./fixtures/landing.json";
import gameLog from "./fixtures/game-log.json";
import score from "./fixtures/score.json";
import {
  GameLogRawSchema,
  LandingRawSchema,
  NhlClient,
  ScoreRawSchema,
  mapGameLog,
  mapLanding,
  officialGameIds,
  teamsThatPlayed,
} from "../src/lib/nhl-api";

describe("transformation des réponses NHL", () => {
  it("ne conserve que les saisons NHL et lit les totaux de carrière", () => {
    const id = mapLanding(LandingRawSchema.parse(landing));
    expect(id.fullName).toBe("Émile Lavoie");
    expect(id.teamAbbrev).toBe("MTL");
    expect(id.careerReportedRegular).toBe(82);
    expect(id.careerReportedPlayoffs).toBe(5);
    expect(id.seasons.every((s) => s.league === "NHL")).toBe(true);
    expect(id.seasons).toHaveLength(4);
    expect(id.seasons.reduce((n, s) => (s.gameType === 2 ? n + s.gamesPlayed : n), 0)).toBe(82);
  });

  it("transforme le journal de matchs", () => {
    const games = mapGameLog(GameLogRawSchema.parse(gameLog), 20262027, 2);
    expect(games).toHaveLength(2);
    expect(games[0]).toMatchObject({ gameId: 2026020241, date: "2026-11-07", opponentAbbrev: "OTT", homeAway: "away", gameType: 2 });
  });

  it("ne tient pour officiels que les matchs à l'état OFF", () => {
    const s = ScoreRawSchema.parse(score);
    expect([...officialGameIds(s)]).toEqual([2026020241]);
    expect([...teamsThatPlayed(s)].sort()).toEqual(["BOS", "MTL", "OTT", "TOR"]);
  });
});

describe("client HTTP", () => {
  it("réessaie après une erreur réseau puis réussit", async () => {
    let calls = 0;
    const fetchImpl = (async () => {
      calls++;
      if (calls < 3) throw new Error("ECONNRESET");
      return new Response(JSON.stringify(score), { status: 200, headers: { "content-type": "application/json" } });
    }) as unknown as typeof fetch;
    const client = new NhlClient({ fetchImpl, minIntervalMs: 0, retries: 3 });
    const origTimeout = globalThis.setTimeout;
    // accélère les délais de reprise
    globalThis.setTimeout = ((fn: () => void) => origTimeout(fn, 0)) as unknown as typeof setTimeout;
    try {
      const s = await client.getScores("2026-11-07");
      expect(s.games).toHaveLength(3);
      expect(calls).toBe(3);
    } finally {
      globalThis.setTimeout = origTimeout;
    }
  });

  it("n'insiste pas sur un 404 ni sur un format inattendu", async () => {
    const notFound = (async () => new Response("", { status: 404 })) as unknown as typeof fetch;
    await expect(new NhlClient({ fetchImpl: notFound, minIntervalMs: 0 }).getPlayerLanding(1)).rejects.toThrow(/404/);
    const weird = (async () => new Response(JSON.stringify({ hello: "world" }), { status: 200 })) as unknown as typeof fetch;
    await expect(new NhlClient({ fetchImpl: weird, minIntervalMs: 0 }).getPlayerLanding(1)).rejects.toThrow(/Format inattendu/);
  });
});
