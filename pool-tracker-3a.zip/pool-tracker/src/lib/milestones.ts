/**
 * Règles de calcul des seuils. Partagées par le script de synchronisation
 * (Node) et par l'interface (navigateur) : une seule implémentation.
 */
import type { Correction, Game, Player, PoolEntry, Threshold, ThresholdEvent } from "./schemas";
import { daysBetween } from "./time";

/** Fusionne deux listes de matchs par identifiant ; les nouveaux l'emportent. */
export function mergeGames(existing: Game[], incoming: Game[]): Game[] {
  const byId = new Map<number, Game>();
  for (const g of existing) byId.set(g.gameId, { ...g, careerOrdinal: undefined });
  for (const g of incoming) byId.set(g.gameId, { ...g, careerOrdinal: undefined });
  return [...byId.values()];
}

/**
 * Trie les matchs par date puis identifiant et attribue le numéro de carrière
 * aux matchs de saison régulière seulement. Les éliminatoires n'en reçoivent pas.
 */
export function numberGames(games: Game[]): Game[] {
  const sorted = [...games].sort((a, b) => a.date.localeCompare(b.date) || a.gameId - b.gameId);
  let ordinal = 0;
  return sorted.map((g) => {
    if (g.gameType === 2) {
      ordinal += 1;
      return { ...g, careerOrdinal: ordinal };
    }
    const { careerOrdinal: _drop, ...rest } = g;
    return rest;
  });
}

export function regularSeasonTotal(games: Game[]): number {
  return games.filter((g) => g.gameType === 2).length;
}

export function playoffTotal(games: Game[]): number {
  return games.filter((g) => g.gameType === 3).length;
}

/** Le total de carrière rapporté par la NHL doit égaler le nombre de lignes du journal. */
export function careerCheck(reported: number | null, games: Game[]): boolean {
  if (reported === null) return false;
  return reported === regularSeasonTotal(games);
}

export function lastGameDate(games: Game[]): string | null {
  return games.reduce<string | null>((acc, g) => (acc === null || g.date > acc ? g.date : acc), null);
}

export function eventId(nhlId: number, thresholdId: string): string {
  return `${nhlId}:${thresholdId}`;
}

/**
 * Détecte les seuils actifs nouvellement franchis. La date d'atteinte est
 * celle du match dont le numéro de carrière égale la valeur du seuil.
 * Idempotent : un seuil déjà consigné (atteint ou révoqué) n'est pas recréé.
 */
export function computeNewEvents(
  player: Pick<Player, "nhlId" | "games">,
  thresholds: Threshold[],
  existing: ThresholdEvent[],
  now: string,
): ThresholdEvent[] {
  const known = new Set(existing.map((e) => e.id));
  const out: ThresholdEvent[] = [];
  for (const t of thresholds) {
    if (!t.isActive) continue;
    const id = eventId(player.nhlId, t.id);
    if (known.has(id)) continue;
    const game = player.games.find((g) => g.careerOrdinal === t.games);
    if (!game) continue;
    out.push({
      id,
      nhlId: player.nhlId,
      thresholdId: t.id,
      thresholdGames: t.games,
      reachedOnGameDate: game.date,
      gameId: game.gameId,
      opponentAbbrev: game.opponentAbbrev,
      totalAtEvent: t.games,
      validatedAt: now,
      status: "reached",
      revokedAt: null,
    });
  }
  return out;
}

/**
 * Une baisse d'un total n'est jamais appliquée en silence : elle est consignée
 * comme correction potentielle et les événements qu'elle remet en cause sont
 * listés, sans être révoqués automatiquement.
 */
export function detectCorrections(
  nhlId: number,
  previous: { regularSeason: number; playoffs: number } | null,
  current: { regularSeason: number; playoffs: number },
  events: ThresholdEvent[],
  now: string,
): Correction[] {
  if (!previous) return [];
  const out: Correction[] = [];
  if (current.regularSeason < previous.regularSeason) {
    out.push({
      id: `${nhlId}:regularSeason:${now}`,
      nhlId,
      detectedAt: now,
      field: "regularSeason",
      previous: previous.regularSeason,
      current: current.regularSeason,
      affectedEventIds: events
        .filter((e) => e.nhlId === nhlId && e.status === "reached" && e.thresholdGames > current.regularSeason)
        .map((e) => e.id),
      reviewed: false,
    });
  }
  if (current.playoffs < previous.playoffs) {
    out.push({
      id: `${nhlId}:playoffs:${now}`,
      nhlId,
      detectedAt: now,
      field: "playoffs",
      previous: previous.playoffs,
      current: current.playoffs,
      affectedEventIds: [],
      reviewed: false,
    });
  }
  return out;
}

/** Prochain seuil actif non atteint, ou null s'il n'en reste aucun. */
export function nextThreshold(regularTotal: number, thresholds: Threshold[]): Threshold | null {
  return (
    thresholds
      .filter((t) => t.isActive && t.games > regularTotal)
      .sort((a, b) => a.games - b.games)[0] ?? null
  );
}

export type StatusKey = "inactive" | "verify" | "recent" | "done" | "one" | "five" | "watch" | "far";

export interface Status {
  key: StatusKey;
  label: string;
  /** vert | orange | rouge | gris | bleu | neutre — toujours accompagné du libellé. */
  tone: "green" | "orange" | "red" | "gray" | "blue" | "neutral";
  nextThreshold: Threshold | null;
  remaining: number | null;
}

export const STATUS_LABELS: Record<StatusKey, string> = {
  inactive: "Joueur inactif ou retiré",
  verify: "Données à vérifier",
  recent: "Seuil récemment atteint",
  done: "Seuil atteint",
  one: "À 1 match du seuil",
  five: "À 5 matchs ou moins",
  watch: "À surveiller",
  far: "Loin du seuil",
};

export const RECENT_DAYS = 7;

export function computeStatus(args: {
  player: Player;
  entry: PoolEntry;
  thresholds: Threshold[];
  events: ThresholdEvent[];
  corrections: Correction[];
  today: string;
}): Status {
  const { player, entry, thresholds, events, corrections, today } = args;
  const next = nextThreshold(player.totals.regularSeason, thresholds);
  const remaining = next ? next.games - player.totals.regularSeason : null;
  const base = { nextThreshold: next, remaining };

  if (entry.trackedUntil !== null || !player.isActive) {
    return { key: "inactive", label: STATUS_LABELS.inactive, tone: "gray", ...base };
  }
  const pendingCorrection = corrections.some((c) => c.nhlId === player.nhlId && !c.reviewed);
  if (!player.totals.careerCheckOk || pendingCorrection) {
    return { key: "verify", label: STATUS_LABELS.verify, tone: "red", ...base };
  }
  const recent = events.some(
    (e) => e.nhlId === player.nhlId && e.status === "reached" && daysBetween(e.reachedOnGameDate, today) <= RECENT_DAYS && daysBetween(e.reachedOnGameDate, today) >= 0,
  );
  if (recent) return { key: "recent", label: STATUS_LABELS.recent, tone: "green", ...base };
  if (next === null || remaining === null) return { key: "done", label: STATUS_LABELS.done, tone: "green", ...base };
  if (remaining === 1) return { key: "one", label: STATUS_LABELS.one, tone: "red", ...base };
  if (remaining <= 5) return { key: "five", label: STATUS_LABELS.five, tone: "orange", ...base };
  if (remaining <= 15) return { key: "watch", label: STATUS_LABELS.watch, tone: "blue", ...base };
  return { key: "far", label: STATUS_LABELS.far, tone: "neutral", ...base };
}
