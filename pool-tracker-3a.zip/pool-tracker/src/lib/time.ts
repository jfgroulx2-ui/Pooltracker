/** Toutes les dates affichées et comparées le sont dans le fuseau de Montréal. */
export const TIME_ZONE = "America/Toronto";

const dateFmt = new Intl.DateTimeFormat("en-CA", {
  timeZone: TIME_ZONE,
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
});

/** Date civile (AAAA-MM-JJ) à Montréal pour un instant donné. */
export function localDate(d: Date = new Date()): string {
  return dateFmt.format(d); // en-CA produit AAAA-MM-JJ
}

export function shiftDate(isoDate: string, days: number): string {
  const [y, m, d] = isoDate.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d + days));
  return dt.toISOString().slice(0, 10);
}

export function yesterdayLocal(now: Date = new Date()): string {
  return shiftDate(localDate(now), -1);
}

function utcMillis(isoDate: string): number {
  const [y, m, d] = isoDate.split("-").map(Number);
  return Date.UTC(y, m - 1, d);
}

export function daysBetween(fromIso: string, toIso: string): number {
  return Math.round((utcMillis(toIso) - utcMillis(fromIso)) / 86_400_000);
}

/**
 * Identifiant de saison NHL (ex. 20262027). La saison bascule en septembre :
 * juillet et août appartiennent encore à la saison qui vient de se terminer.
 */
export function currentSeasonId(isoDate: string = localDate()): number {
  const [y, m] = isoDate.split("-").map(Number);
  const startYear = m >= 9 ? y : y - 1;
  return startYear * 10_000 + (startYear + 1);
}

/** Lundi à Montréal = jour du rafraîchissement complet hebdomadaire. */
export function isMonday(isoDate: string): boolean {
  const [y, m, d] = isoDate.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d)).getUTCDay() === 1;
}

const displayFmt = new Intl.DateTimeFormat("fr-CA", {
  timeZone: TIME_ZONE,
  weekday: "short",
  day: "numeric",
  month: "short",
  year: "numeric",
});
const displayTimeFmt = new Intl.DateTimeFormat("fr-CA", {
  timeZone: TIME_ZONE,
  day: "numeric",
  month: "long",
  year: "numeric",
  hour: "numeric",
  minute: "2-digit",
});

export function formatDate(isoDate: string): string {
  const [y, m, d] = isoDate.split("-").map(Number);
  return displayFmt.format(new Date(Date.UTC(y, m - 1, d, 12)));
}

export function formatDateTime(iso: string): string {
  return displayTimeFmt.format(new Date(iso));
}
