/**
 * Client pour les services publics de la NHL (non documentés officiellement).
 *   - https://api-web.nhle.com/v1     fiche joueur, journal de matchs, scores
 *   - https://search.d3.nhle.com      recherche de joueurs par nom
 *
 * Règles : cadence ≤ 1 requête/seconde, 3 tentatives avec délai croissant,
 * délai d'attente de 15 s, validation de la forme des réponses avec Zod.
 */
import { z } from "zod";
import type { Game, GameType, SeasonTotal } from "./schemas";

export const WEB_API = "https://api-web.nhle.com/v1";
export const SEARCH_API = "https://search.d3.nhle.com/api/v1/search/player";

export interface ClientOptions {
  /** Intervalle minimal entre deux requêtes (ms). */
  minIntervalMs?: number;
  retries?: number;
  timeoutMs?: number;
  fetchImpl?: typeof fetch;
  log?: (msg: string) => void;
}

export class NhlApiError extends Error {
  constructor(message: string, public readonly status?: number, public readonly url?: string) {
    super(message);
    this.name = "NhlApiError";
  }
}

// ---------- Formes brutes (lenientes : les champs inconnus sont conservés) ----------

const LocalizedString = z.object({ default: z.string() }).passthrough();

export const LandingRawSchema = z
  .object({
    playerId: z.number(),
    isActive: z.boolean().optional(),
    currentTeamAbbrev: z.string().optional(),
    firstName: LocalizedString,
    lastName: LocalizedString,
    position: z.string(),
    headshot: z.string().optional(),
    careerTotals: z
      .object({
        regularSeason: z.object({ gamesPlayed: z.number() }).passthrough().optional(),
        playoffs: z.object({ gamesPlayed: z.number() }).passthrough().optional(),
      })
      .passthrough()
      .optional(),
    seasonTotals: z
      .array(
        z
          .object({
            season: z.number(),
            leagueAbbrev: z.string(),
            gameTypeId: z.number(),
            gamesPlayed: z.number(),
            teamName: LocalizedString.optional(),
          })
          .passthrough(),
      )
      .default([]),
  })
  .passthrough();
export type LandingRaw = z.infer<typeof LandingRawSchema>;

export const GameLogRawSchema = z
  .object({
    seasonId: z.number().optional(),
    gameTypeId: z.number().optional(),
    gameLog: z
      .array(
        z
          .object({
            gameId: z.number(),
            gameDate: z.string(),
            teamAbbrev: z.string(),
            opponentAbbrev: z.string(),
            homeRoadFlag: z.string(),
          })
          .passthrough(),
      )
      .default([]),
  })
  .passthrough();
export type GameLogRaw = z.infer<typeof GameLogRawSchema>;

export const ScoreRawSchema = z
  .object({
    games: z
      .array(
        z
          .object({
            id: z.number(),
            gameState: z.string(),
            gameDate: z.string().optional(),
            awayTeam: z.object({ abbrev: z.string() }).passthrough(),
            homeTeam: z.object({ abbrev: z.string() }).passthrough(),
          })
          .passthrough(),
      )
      .default([]),
  })
  .passthrough();
export type ScoreRaw = z.infer<typeof ScoreRawSchema>;

export const SearchRawSchema = z.array(
  z
    .object({
      playerId: z.coerce.number(),
      name: z.string(),
      positionCode: z.string().optional(),
      teamAbbrev: z.string().nullable().optional(),
      active: z.boolean().optional(),
    })
    .passthrough(),
);
export type SearchHit = z.infer<typeof SearchRawSchema>[number];

// ---------- Client ----------

export class NhlClient {
  private lastRequestAt = 0;
  private readonly minIntervalMs: number;
  private readonly retries: number;
  private readonly timeoutMs: number;
  private readonly fetchImpl: typeof fetch;
  private readonly log: (msg: string) => void;
  public requestCount = 0;

  constructor(opts: ClientOptions = {}) {
    this.minIntervalMs = opts.minIntervalMs ?? 1000;
    this.retries = opts.retries ?? 3;
    this.timeoutMs = opts.timeoutMs ?? 15_000;
    this.fetchImpl = opts.fetchImpl ?? fetch;
    this.log = opts.log ?? (() => {});
  }

  private async throttle(): Promise<void> {
    const wait = this.lastRequestAt + this.minIntervalMs - Date.now();
    if (wait > 0) await new Promise((r) => setTimeout(r, wait));
    this.lastRequestAt = Date.now();
  }

  async getJson<S extends z.ZodTypeAny>(url: string, schema: S): Promise<z.output<S>> {
    let lastError: unknown;
    for (let attempt = 1; attempt <= this.retries; attempt++) {
      await this.throttle();
      this.requestCount++;
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), this.timeoutMs);
      try {
        const res = await this.fetchImpl(url, {
          signal: controller.signal,
          headers: { accept: "application/json", "user-agent": "pool-tracker/0.1 (usage personnel)" },
          redirect: "follow",
        });
        if (res.status === 404) throw new NhlApiError("Ressource introuvable (404)", 404, url);
        if (!res.ok) throw new NhlApiError(`Réponse HTTP ${res.status}`, res.status, url);
        const json: unknown = await res.json();
        const parsed = schema.safeParse(json);
        if (!parsed.success) {
          throw new NhlApiError(`Format inattendu : ${parsed.error.issues[0]?.path.join(".")} — ${parsed.error.issues[0]?.message}`, res.status, url);
        }
        return parsed.data;
      } catch (err) {
        lastError = err;
        const status = err instanceof NhlApiError ? err.status : undefined;
        // 404 et format inattendu : réessayer ne changera rien.
        if (status === 404 || (err instanceof NhlApiError && err.message.startsWith("Format inattendu"))) throw err;
        this.log(`Tentative ${attempt}/${this.retries} échouée pour ${url} : ${(err as Error).message}`);
        if (attempt < this.retries) await new Promise((r) => setTimeout(r, 1500 * 2 ** (attempt - 1)));
      } finally {
        clearTimeout(timer);
      }
    }
    throw lastError instanceof Error ? lastError : new NhlApiError(String(lastError), undefined, url);
  }

  getPlayerLanding(nhlId: number): Promise<LandingRaw> {
    return this.getJson(`${WEB_API}/player/${nhlId}/landing`, LandingRawSchema);
  }

  getGameLog(nhlId: number, season: number, gameType: GameType): Promise<GameLogRaw> {
    return this.getJson(`${WEB_API}/player/${nhlId}/game-log/${season}/${gameType}`, GameLogRawSchema);
  }

  getScores(isoDate: string): Promise<ScoreRaw> {
    return this.getJson(`${WEB_API}/score/${isoDate}`, ScoreRawSchema);
  }

  searchPlayers(query: string, limit = 20): Promise<SearchHit[]> {
    const url = `${SEARCH_API}?culture=en-us&limit=${limit}&q=${encodeURIComponent(query)}`;
    return this.getJson(url, SearchRawSchema);
  }
}

// ---------- Transformation vers notre modèle ----------

export interface LandingIdentity {
  nhlId: number;
  firstName: string;
  lastName: string;
  fullName: string;
  position: string;
  teamAbbrev: string | null;
  isActive: boolean;
  headshotUrl: string | null;
  careerReportedRegular: number | null;
  careerReportedPlayoffs: number | null;
  /** Saisons NHL uniquement (saison régulière et éliminatoires). */
  seasons: SeasonTotal[];
}

export function mapLanding(raw: LandingRaw): LandingIdentity {
  const seasons: SeasonTotal[] = raw.seasonTotals
    .filter((s) => s.leagueAbbrev === "NHL" && (s.gameTypeId === 2 || s.gameTypeId === 3))
    .map((s) => ({
      season: s.season,
      league: s.leagueAbbrev,
      gameType: s.gameTypeId as GameType,
      gamesPlayed: s.gamesPlayed,
      teamName: s.teamName?.default ?? null,
    }))
    .sort((a, b) => a.season - b.season || a.gameType - b.gameType);

  return {
    nhlId: raw.playerId,
    firstName: raw.firstName.default,
    lastName: raw.lastName.default,
    fullName: `${raw.firstName.default} ${raw.lastName.default}`.trim(),
    position: raw.position,
    teamAbbrev: raw.currentTeamAbbrev ?? null,
    isActive: raw.isActive ?? false,
    headshotUrl: raw.headshot ?? null,
    careerReportedRegular: raw.careerTotals?.regularSeason?.gamesPlayed ?? null,
    careerReportedPlayoffs: raw.careerTotals?.playoffs?.gamesPlayed ?? null,
    seasons,
  };
}

export function mapGameLog(raw: GameLogRaw, season: number, gameType: GameType): Game[] {
  return raw.gameLog.map((g) => ({
    gameId: g.gameId,
    date: g.gameDate.slice(0, 10),
    season,
    gameType,
    teamAbbrev: g.teamAbbrev,
    opponentAbbrev: g.opponentAbbrev,
    homeAway: g.homeRoadFlag === "H" ? "home" : "away",
  }));
}

/** Identifiants des matchs officiels (état OFF) pour une date donnée. */
export function officialGameIds(score: ScoreRaw): Set<number> {
  return new Set(score.games.filter((g) => g.gameState === "OFF").map((g) => g.id));
}

/** Équipes ayant un match terminé (FINAL ou OFF) à cette date. */
export function teamsThatPlayed(score: ScoreRaw): Set<string> {
  const out = new Set<string>();
  for (const g of score.games) {
    if (g.gameState === "OFF" || g.gameState === "FINAL") {
      out.add(g.awayTeam.abbrev);
      out.add(g.homeTeam.abbrev);
    }
  }
  return out;
}
