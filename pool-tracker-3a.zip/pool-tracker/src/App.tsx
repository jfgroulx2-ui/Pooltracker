import { computeStatus, type Status } from "./lib/milestones";
import { formatDate, formatDateTime, localDate } from "./lib/time";
import { corrections, events, players, pool, syncLog, thresholds } from "./data";

/**
 * Socle d'interface (module 3a) : tableau de bord lisant directement data/.
 * Les écrans complets de la Phase 2 arrivent au module 3d.
 */
export default function App() {
  const today = localDate();
  const lastRun = syncLog[0] ?? null;
  const rows = pool
    .filter((e) => e.trackedUntil === null)
    .map((entry) => {
      const player = players.get(entry.nhlId);
      if (!player) return null;
      const status = computeStatus({ player, entry, thresholds, events, corrections, today });
      return { entry, player, status };
    })
    .filter((r): r is NonNullable<typeof r> => r !== null)
    .sort((a, b) => (a.status.remaining ?? 9999) - (b.status.remaining ?? 9999) || a.player.lastName.localeCompare(b.player.lastName));

  const count = (pred: (s: Status) => boolean) => rows.filter((r) => pred(r.status)).length;
  const recentEvents = events.filter((e) => e.status === "reached" && e.reachedOnGameDate >= shiftBack(today, 7)).length;

  return (
    <div className="shell">
      <nav className="nav" aria-label="Navigation principale">
        <div className="brand"><span>PT</span>POOL TRACKER</div>
        <a href="/" aria-current="page">Tableau de bord</a>
        <a href="/logout">Se déconnecter</a>
        <div className="foot">{thresholds.filter((t) => t.isActive).length} seuil(s) actif(s)<br />Fuseau : Montréal</div>
      </nav>
      <main className="main">
        <div>
          <h1>Tableau de bord</h1>
          <p className="sub">
            {lastRun
              ? `Dernière synchronisation : ${formatDateTime(lastRun.startedAt)} · ${statusWord(lastRun.status)} · ${lastRun.playersChecked} joueur(s) vérifié(s)`
              : "Aucune synchronisation exécutée pour l'instant."}
          </p>
        </div>

        <section className="cards" aria-label="Indicateurs">
          <div className="card" style={{ ["--c" as string]: "#b91c1c" }}><div className="l">À 1 match d'un seuil</div><div className="n">{count((s) => s.key === "one")}</div></div>
          <div className="card" style={{ ["--c" as string]: "#c2410c" }}><div className="l">À 5 matchs ou moins</div><div className="n">{count((s) => s.key === "one" || s.key === "five")}</div></div>
          <div className="card" style={{ ["--c" as string]: "#15803d" }}><div className="l">Seuils atteints (7 jours)</div><div className="n">{recentEvents}</div></div>
          <div className="card" style={{ ["--c" as string]: "#6b7280" }}><div className="l">Données à vérifier</div><div className="n">{count((s) => s.key === "verify")}</div></div>
        </section>

        <section className="panel" aria-label="Joueurs de mon pool">
          <header><h2>Mon pool — {rows.length} joueur(s) suivi(s)</h2></header>
          {rows.length === 0 ? (
            <p className="empty">
              Aucun joueur suivi. Ajoutez une entrée dans <code>data/pool.json</code> puis lancez la synchronisation — l'écran d'ajout arrive au module 3b.
            </p>
          ) : (
            <div className="scroll">
              <table>
                <thead>
                  <tr><th>Joueur</th><th>Équipe</th><th>Pos.</th><th className="num">Rég.</th><th className="num">Élim.</th><th className="num">Prochain</th><th className="num">Restants</th><th>Dernier match</th><th>Statut</th></tr>
                </thead>
                <tbody>
                  {rows.map(({ player, status }) => (
                    <tr key={player.nhlId}>
                      <td><strong>{player.fullName}</strong></td>
                      <td>{player.teamAbbrev ?? "—"}</td>
                      <td>{player.position}</td>
                      <td className="num">{player.totals.regularSeason}</td>
                      <td className="num" style={{ color: "var(--muted)" }}>{player.totals.playoffs}</td>
                      <td className="num">{status.nextThreshold?.games ?? "—"}</td>
                      <td className="num"><strong>{status.remaining ?? "—"}</strong></td>
                      <td>{player.lastGameDate ? formatDate(player.lastGameDate) : "—"}</td>
                      <td><span className={`badge ${status.tone}`}>{status.label}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}

function statusWord(s: "success" | "partial" | "failed"): string {
  return s === "success" ? "réussie" : s === "partial" ? "partielle" : "échouée";
}

function shiftBack(iso: string, days: number): string {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d - days)).toISOString().slice(0, 10);
}
